#!/bin/bash
# Genera los entregables del TP en /home/entrega
OUT=/home/entrega
mkdir -p "$OUT"
cd "$OUT" || exit 1
for d in root etc opt www_dir backup_dir; do
  tar -czpf "$d.tar.gz" -C / "$d" 2>/dev/null
  echo "$d: rc=$?"
done
# /var se divide en partes de 20 MB para poder subirlo a GitHub
tar -czpf - -C / var 2>/dev/null | split -b 20M -d - var.tar.gz.part_
sha256sum *.tar.gz var.tar.gz.part_* > SHA256SUMS
ls -lh
cat var.tar.gz.part_* | tar -tzf - > /dev/null && echo VAR_VERIFICADO
rm -f /root/entrega.sh
