history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
clear; setterm -blank 0; tail -12 /root/upgrade2.log; ps  | grep -E 'apt|dpkg' | grep -v grep | head -5
clear; tail -15 /root/upgrade.log
clear; tail -8 /root/upgrade.log; cat /etc/debian_version
clear; export DEBIAN_FRONTEND=noninteractive; echo 'grub-pc grub-pc/install_devices multiselect /dev/sda' | debconf-set-selections; O='-o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold'; (dpkg --configure -a && apt-get -y $O -f install && apt-get -y $O full-upgrade && apt-get -y install openssh-server && apt-get -y autoremove && echo UPGRADE_OK) > /root/upgrade2.log 2>&1; tail -6 /root/upgrade2.log
loadkeys us
clearñ echo -'Ñ]:°?¿"ñ ip 'br añ ip rñ cat -etc-apt-sources.listñ ls 'la -rootñ lsblk
CLEAR; ECHO '/-:|>~_=@{}[]*+#^\'; IP -BR A; IP R; GREP -V '^#' /ETC/APT/SOURCES.LIST; LS -LA /ROOT; LSBLK
clear; echo 'aZ/-:|>~_=@{}[]*+#^\'; ip -br a; ip r; grep -v '^#' /etc/apt/sources.list; ls -la /root; lsblk
clear; mkdir -p /root/.ssh && chmod 700 /root/.ssh && echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIBsFFtocWbi6myfEm7dz2MJk0zcbd3jXcdfbtO82SU2F claude-tp' >> /root/.ssh/authorized_keys && chmod 600 /root/.ssh/authorized_keys && cat /root/.ssh/authorized_keys && apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y openssh-server && systemctl enable --now ssh && echo SSH_LISTO
clear; cat /etc/resolv.conf; ls -la /etc/resolv.conf; ping -c2 8.8.8.8; cat /etc/network/interfaces; cat /etc/hosts
clear; ifdown enp0s3; ifup enp0s3; ip -br a; ip r; cat /etc/resolv.conf; ping -c2 deb.debian.org
clear; cp /etc/apt/sources.list /etc/apt/sources.list.orig; printf 'deb http://deb.debian.org/debian bullseye main contrib non-free\ndeb http://deb.debian.org/debian bullseye-updates main contrib non-free\ndeb http://security.debian.org/debian-security bullseye-security main contrib non-free\n' > /etc/apt/sources.list; apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y openssh-server && systemctl enable --now ssh && echo SSH_LISTO
clear; date -s '2026-11-09 19:58:59'; sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list; sed -i 's/contrib non-free/contrib non-free non-free-firmware/' /etc/apt/sources.list; cat /etc/apt/sources.list; export DEBIAN_FRONTEND=noninteractive; (apt-get update && apt-get -y -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold upgrade --without-new-pkgs && apt-get -y -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold full-upgrade && apt-get install -y openssh-server && echo UPGRADE_OK) > /root/upgrade.log 2>&1; tail -5 /root/upgrade.log; cat /etc/debian_version
clear; grep -iE 'err|fall|W:|E:' /root/upgrade.log | head -30
clear; ip -br a; ping -c3 192.168.0.1; ping -c3 8.8.8.8; getent hosts deb.debian.org
clear; echo 'Acquire::ForceIPv4 \"true\";' > /etc/apt/apt.conf.d/99force-ipv4; cat /etc/apt/apt.conf.d/99force-ipv4; echo 'nameserver 8.8.8.8' >> /etc/resolv.conf; export DEBIAAN_FRONTEND=noninteractive; O='-o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold'; (apt-get update && apt-get -y $O upgrade --without-new-pkgs && apt-get -y $O full-upgrade && apt-get -y install openssh-server && echo UPGRADE_OK) > /root/upgrade.log 2>&1; tail -3 /root/upgrade.log; cat /etc/debian_version
